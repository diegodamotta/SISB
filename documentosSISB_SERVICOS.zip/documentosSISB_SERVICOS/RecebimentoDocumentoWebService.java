/**
 * 
 */
package br.com.bradseg.sisb.servicos.recebimentodocumento.webservice;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bradseg.sisb.servicos.recebimentodocumento.dto.DocumentoAnexoDTO;
import br.com.bradseg.sisb.servicos.recebimentodocumento.dto.RecebimentoDocumentoDTO;
import br.com.bradseg.sisb.servicos.recebimentodocumento.facade.DocumentoFacade;

import com.ibm.ws.webservices.engine.encoding.Base64;

/**
 * Classe se servico de recebimento de senha.
 *
 */
@Service
@WebService
public class RecebimentoDocumentoWebService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RecebimentoDocumentoWebService.class);
	
	@Autowired private DocumentoFacade documentoFacade;
	
	/**
	 * Realiza o recebimento de documentos para ser enviado para o SIAI.
	 * 
	 * @param doc dados do documento.
	 * @return Retorno do envio.
	 */
	@WebMethod
	public RecebimentoDocumentoDTO receberDocumentoOrizon(RecebimentoDocumentoDTO doc) {
		return documentoFacade.receberDocumentoOrizon(doc);
	}
	
    /**
     * M�todo respons�vel por anexar documento.
     * 
     * @param dados Dados de inclus�o do Anexo.
     * @return verdadeiro se a opera��o foi realizada com sucesso, falso caso contr�rio
     */
	@WebMethod
	public boolean anexarDocumento(DocumentoAnexoDTO dados) {
		try {
			LOGGER.error("######## ANEXANDO DOCUMENTOS ########");
			LOGGER.error("Login " + dados.getUsuario().getLogin());
			LOGGER.error("Usuario " + dados.getUsuario().getCodigoUsuario());
			LOGGER.error("Nome Usuario " + dados.getUsuario().getNomeUsuario());
			LOGGER.error("Perfil Usuario " + dados.getUsuario().getPerfil());
			LOGGER.error("Solicitacao  " + dados.getNumeroGuia());
			LOGGER.error("Senha " + dados.getSenha());
			LOGGER.error("cartao " + dados.getCartaoSegurado());
			LOGGER.error("Referenciado " + dados.getCodigoReferenciado());
			LOGGER.error("Codigo Evento " + dados.getCodigoEvento());
			LOGGER.error("Codigo Aditivo " + dados.getCodigoAditivo());
			
			String strStreamArquivo = Base64.encode(inputStreamToByteArray(new ByteArrayInputStream(dados.getInputStreamArquivo())));
			return documentoFacade.anexarDocumento(strStreamArquivo, Long.parseLong(dados.getNumeroGuia()), dados.getSenha(), 
			        dados.getCartaoSegurado(), dados.getCodigoReferenciado(), dados.getMimeType(), dados.getFileName(), 
			        dados.getCodigoEvento(), dados.getUsuario(), dados.getCodigoAditivo());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}	
	}
	
	/**
	 * M�todo para converter um inputStream para um ByteArray
	 * 
	 * @param inputStream do tipo InputStream
	 * @return InputStream convertido em um ByteArray
	 * @throws IOException
	 */
	private byte[] inputStreamToByteArray(InputStream inputStream) throws IOException {
		ByteArrayOutputStream byteArrayStream = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		if (inputStream.markSupported()) {
			inputStream.reset();
		}
		int tamanhoArquivo = inputStream.read(buffer);
		while (tamanhoArquivo >= 0) {
			byteArrayStream.write(buffer, 0, tamanhoArquivo);
			tamanhoArquivo = inputStream.read(buffer);
		}
		byteArrayStream.flush();
		return byteArrayStream.toByteArray();
	}
}
