/**
 * 
 */
package br.com.bradseg.sisb.servicos.filasenhas.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.QueueBrowser;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.BrowserCallback;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.bradseg.sisb.servicos.filasenhas.vo.DadosSenhaVO;

/**
 * Classe de envio de dados para a fila MQ.
 */
@Component
@Transactional(propagation = Propagation.NOT_SUPPORTED)
public class DadosSenhaJmsSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(DadosSenhaJmsSender.class);
	
	@Autowired(required=false) private JmsTemplate filaSenhasSCAM;
//	@Autowired private JmsTemplate filaSenhasSSCF;
	@Autowired(required=false) private JmsTemplate filaSenhasORZN;
	
//	@Resource
//    private Queue filaDadosSenhasSSCF;

	/**
	 * Envia os dados da senha para a Fila MQ do SCAM.
	 * @param dadosSenha dados da senha.
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void enviarMensagemCancelamentoSCAM(DadosSenhaVO dadosSenha) {
		try {
			dadosSenha.setOrigem("2");
			LOGGER.error("$$$$$$ FILA SCAM $$$$$$");
			filaSenhasSCAM.convertAndSend(dadosSenha);
		} catch (Exception e) {
			logarExceptionMQ(e);
		}
	}

	/**
	 * Envia os dados da senha para a Fila MQ do SSCF
	 * 
	 * @param dadosSenha dados da senha.
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void enviarMensagemCancelamentoSSCF(final DadosSenhaVO dadosSenha) {
//		try {
//			dadosSenha.setOrigem("2");
//			LOGGER.error("$$$$$$ FILA SSCF $$$$$$");
//			
//			final String mensagem = new StringBuilder()
//								.append(StringUtils.repeat("0", 3))
//								.append(dadosSenha.getSenha().trim())
//								.append(dadosSenha.getDataCancelamento())
//								.append(StringUtils.repeat("0", 60))
//			.toString();
//			
//			filaSenhasSSCF.send(filaDadosSenhasSSCF, new MessageCreator() {
//				@Override
//				public TextMessage createMessage(Session session) throws JMSException {
//					TextMessage message = session.createTextMessage();
//					message.setIntProperty("JMS_IBM_Character_Set", 37);
//					message.setText(mensagem);
//					return message;
//				}
//			});
//		} catch (Exception e) {
//			logarExceptionMQ(e);
//		}
	}

	/**
	 * Envia os dados da senha para a Fila MQ.
	 * 
	 * @param dadosSenha dados da senha.
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void enviarMensagemCancelamentoOrizon(DadosSenhaVO dadosSenha) {
		try {
			dadosSenha.setOrigem("1");
			LOGGER.error("$$$$$$ FILA ORZN $$$$$$");
			filaSenhasORZN.convertAndSend(dadosSenha);
		} catch (Exception e) {
			logarExceptionMQ(e);
		}
	}
	
	private void logarExceptionMQ(Exception e) {
		LOGGER.error("EXCEPTION TYPE " + e.getClass().toString());
		LOGGER.error("EXCEPTION CAUSE " + e.getCause().toString());
		LOGGER.error("EXCEPTION MESSAGE " + e.getMessage().toString());
	}

	/**
	 * Envia os dados da senha para a Fila MQ.
	 * 
	 * @param dadosSenha dados da senha.
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void enviarMensagemNotificacao(DadosSenhaVO dadosSenha) {
		dadosSenha.setOrigem("1");
		filaSenhasORZN.convertAndSend(dadosSenha);
	}


	/** {@inheritDoc} */
	public List<DadosSenhaVO> listarFilaDadosSenhaSCAM() {
		return listarFilaDadosSenha(filaSenhasSCAM);
	}

	/** {@inheritDoc} */
	public List<DadosSenhaVO> listarFilaDadosSenhaSSCF() {
//		return listarFilaDadosSenha(filaSenhasSSCF);
		return new ArrayList<DadosSenhaVO>();
	}

	/** {@inheritDoc} */
	public List<DadosSenhaVO> listarFilaDadosSenhaORZN() {
		return listarFilaDadosSenha(filaSenhasORZN);
	}

	/** {@inheritDoc} */
	private List<DadosSenhaVO> listarFilaDadosSenha(JmsTemplate fila) {
		return fila.browse(new BrowserCallback<List<DadosSenhaVO>>() {
			@Override
			@SuppressWarnings("unchecked")
			public List<DadosSenhaVO> doInJms(Session session, QueueBrowser fila) throws JMSException {
				List<DadosSenhaVO> dados = new ArrayList<DadosSenhaVO>();
				Enumeration<Object> e = fila.getEnumeration();
				while (e.hasMoreElements()) {
					Object obj = e.nextElement();
					if (obj instanceof Message) {
						DadosSenhaMessageConverter c = new DadosSenhaMessageConverter();
						DadosSenhaVO vo = (DadosSenhaVO) c.fromMessage((Message) obj);
						vo.setSenha(vo.getSenha() + '-' + fila.getQueue().getQueueName());
						dados.add(vo);
						if (dados.size() > 1000) {
							break;
						}
						LOGGER.error(vo.getSenha() + " - " + vo.getDataCancelamento());
					}
				}
				return dados;
			}
		});
	}

	/** {@inheritDoc} */
	public void consumirFilaMQSCAM() {
		consumirFilaMQ(filaSenhasSCAM);
	}

	/** {@inheritDoc} */
	public void consumirFilaMQSSCF() {
//		consumirFilaMQ(filaSenhasSSCF);
	}

	/** {@inheritDoc} */
	public void consumirFilaMQORZN() {
		consumirFilaMQ(filaSenhasORZN);
	}

	/** {@inheritDoc} */
	public void consumirFilaMQ(JmsTemplate fila) {
		DadosSenhaVO vo = (DadosSenhaVO) fila.receiveAndConvert();
		if (vo != null) {
			LOGGER.error(fila.getDefaultDestinationName() + " Senha::" + vo.getSenha() + " Solicitacao::" + vo.getSolicitacao());
		}
	}
}