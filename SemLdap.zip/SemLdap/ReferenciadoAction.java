package br.com.bradseg.sisb.solicitacaointernacaoexame.controller.internet.referenciado.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

import br.com.bradseg.bsad.exception.BusinessException;
import br.com.bradseg.bsad.exception.IntegrationException;
import br.com.bradseg.pcbs.servicossaude.model.vo.BairroVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.CidadeVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.CodigoReferenciadoVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.EnderecoVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.ReferenciadoVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.SessaoVO;
import br.com.bradseg.pcbs.servicossaude.model.vo.TelefoneVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.UFVo;
import br.com.bradseg.pcbs.servicossaude.model.vo.UsuarioVO;
import br.com.bradseg.pcbs.servicossaude.util.exception.CodigoReferenciadoInvalidoBusinessException;
import br.com.bradseg.sisb.solicitacaointernacaoexame.controller.form.internet.referenciado.ReferenciadoForm;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.analise.delegate.ComunicacaoAtendimentoDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.analise.delegate.internet.ReferenciadoDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.parametro.delegate.ParametroDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.tabelascorporativas.delegate.TabelasCorporativasDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.util.SisbUtil;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.ComunicacaoAtendimentoVO;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.ParametroVO;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.ReferenciadoCondicoesGeraisVO;
import br.com.cpmbraxis.framework.aop.annotation.Log;
import br.com.cpmbraxis.framework.controller.struts.AbstractDispatchAction;
import br.com.cpmbraxis.framework.type.LogLevel;

/**
 * Action para o referenciado.
 * @author Capgemini
 */
public class ReferenciadoAction extends AbstractDispatchAction {

    private static final Logger LOGGER = Logger.getLogger(ReferenciadoAction.class);
    private static final String FORWARD_SUCESSO = "sucesso";
    private static final String FORWARD_ERRO = "erro";
    private static final String FORWARD_MANUTENCAO = "manutencao";
    private static final String STR_CODIGO_REFERENCIADO = "codigoReferenciado";

    private SessaoVO sessaoVoFake() throws CodigoReferenciadoInvalidoBusinessException {
        
        SessaoVO sessaoVo = new SessaoVO();

        UsuarioVO usuario = new UsuarioVO();
        usuario.setCodigoIdentificacao("60922168000348");
        usuario.setNome("Charles Chaplin");
                
        sessaoVo.setUsuarioVO(usuario);
        
        ReferenciadoVo referenciadoVo = new ReferenciadoVo();
        
        CodigoReferenciadoVo codigoReferenciado = new CodigoReferenciadoVo("111511");
        referenciadoVo.setNomeFantasia("NOME FANTASIA");
        
        CodigoReferenciadoVo codigoReferenciado2 = new CodigoReferenciadoVo("547727");
        
        CodigoReferenciadoVo codigoReferenciado3 = new CodigoReferenciadoVo("5312");
        
        List<CodigoReferenciadoVo> codigosReferenciado = Arrays.asList(codigoReferenciado, codigoReferenciado2, codigoReferenciado3);
        
        EnderecoVo endereco = new EnderecoVo();
        BairroVo bairro = new BairroVo();
        CidadeVo cidade = new CidadeVo();
        UFVo uf = new UFVo();
        
        bairro.setDescricao("M�ier");
        cidade.setDescricao("Rio de Janeiro");
        uf.setSigla("RJ");
        
        endereco.setBairro(bairro);
        endereco.setCidade(cidade);
        endereco.setUf(uf);
        
        referenciadoVo.setEndereco(endereco);
        referenciadoVo.setCodigosReferenciado(codigosReferenciado);
        
        List<TelefoneVo> listaTelefones = new ArrayList<TelefoneVo>();
        
        TelefoneVo telefone = new TelefoneVo();
        telefone.setDdd(021);
        telefone.setNumero(99999999L);
        telefone.setRamal(2262);
        
        listaTelefones.add(telefone);
        
        referenciadoVo.setListaTelefones(listaTelefones);
        
        sessaoVo.setUsuarioObject(referenciadoVo);
       
        return sessaoVo;
    }

    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward referenciadoFiltro( ActionMapping mapping, ActionForm form, HttpServletRequest request,
        HttpServletResponse response ) throws IntegrationException, BusinessException {

        HttpSession session = request.getSession();

        ActionForward forward = mapping.findForward(FORWARD_SUCESSO);

        ReferenciadoForm formulario = (ReferenciadoForm) form;

        SessaoVO sessaoVo = sessaoVoFake();
//        SessaoVO sessaoVo = (SessaoVO) session.getAttribute("sessaoVO");

        ReferenciadoDelegate delegate = ReferenciadoDelegate.getInstance();

        if(sessaoVo == null) {
            LOGGER.fatal("Entrou, na sess�o nula");

            mensagemErro(request, "msg.erro.interno");
            forward = mapping.findForward(FORWARD_ERRO);
        } else {
            LOGGER.fatal("Entrou, na sess�o n�o nula");

            UsuarioVO usuario = sessaoVo.getUsuarioVO();
            ReferenciadoVo referenciadoVo = (ReferenciadoVo)sessaoVo.getUsuarioObject();

            Integer sqlCode = delegate.gravaUsuarioCom(SisbUtil.completaCPF(usuario.getCodigoIdentificacao()), usuario.getNome()); 
            if(sqlCode != 0) {
                LOGGER.fatal("Entrou, SQLCODE != 0");
                mensagemErro(request, "msg.erro.interno");
                forward = mapping.findForward(FORWARD_ERRO);
            }
            String dataStringAtual = SisbUtil.getDataAtual(request);

            //referenciadoVo = delegate.obterReferenciado(referenciadoVo.getCpfCnpj());
            session.setAttribute("sessaoVO", sessaoVo);
            if(referenciadoVo != null) {
                LOGGER.fatal("Entrou, ReferenciadoVo != null ");
                session.setAttribute("listaReferenciado", referenciadoVo.getCodigosReferenciado());
                
                formulario.setCodigosDoReferenciado(referenciadoVo.getCodigosReferenciado());
                formulario.setNomeFantasia(referenciadoVo.getNomeFantasia());
                formulario.setEndereco(referenciadoVo.getEndereco());
                formulario.setTelefone(obterTelefone(referenciadoVo.getListaTelefones()));

                if (isSistemaEmManutencao(referenciadoVo.getCpfCnpj())) {
                    forward = mapping.findForward(FORWARD_MANUTENCAO);
                }
            } else {
                LOGGER.fatal("Entrou, ReferenciadoVo == null ");

                mensagemErro(request, "msg.erro.interno");
                forward = mapping.findForward(FORWARD_ERRO);
            }
            
            session.setAttribute("perfil", "ATE.INTAO");
            session.setAttribute("codigoUsuario", SisbUtil.completaCPF(usuario.getCodigoIdentificacao()));
            
            //Gera o codigo sequencial de atendimento
            ComunicacaoAtendimentoVO comunicacaoAtendimentoVOParam = new ComunicacaoAtendimentoVO();
            comunicacaoAtendimentoVOParam.setCodigoUsuario(SisbUtil.completaCPF(usuario.getCodigoIdentificacao()));
            comunicacaoAtendimentoVOParam.setDataInicioComunicacao(dataStringAtual);
            //tipo de canal indica que a solicita��o est� vindo do sisb web
            comunicacaoAtendimentoVOParam.setTipoCanal("2");
            comunicacaoAtendimentoVOParam = ComunicacaoAtendimentoDelegate.getInstance().gerarSequencialComunicacaoAtendimento(comunicacaoAtendimentoVOParam);
            
            session.setAttribute("sequencialComunicacaoAtendimento", comunicacaoAtendimentoVOParam.getSequencialComunicacaoAtendimento());
   
            formulario.setNome(usuario.getNome());
        }
        
        LOGGER.fatal("Entrou, forward = " + forward);
        
        return forward;
    }
    
    /**
     * @param listaTelefones
     * @return
     */
    private TelefoneVo obterTelefone(List<TelefoneVo> listaTelefones) {
        
        TelefoneVo telefone = new TelefoneVo();
        
        telefone.setDdd(listaTelefones.get(0).getDdd());
        telefone.setNumero(listaTelefones.get(0).getNumero());
        telefone.setRamal(listaTelefones.get(0).getRamal());
        
        return telefone;
    }

    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward gravaDadosDoFuncionarioNaSessao( ActionMapping mapping, ActionForm form, HttpServletRequest request,
        HttpServletResponse response ) {
        
        HttpSession session = request.getSession();
        
        ActionForward forward = mapping.findForward(FORWARD_SUCESSO);
        
        ReferenciadoForm formulario = (ReferenciadoForm) form;
        
        ReferenciadoVo referenciado = new ReferenciadoVo();
        referenciado.setNomeFantasia(formulario.getNomeFantasia());
        referenciado.setNome(formulario.getNome());
        referenciado.setFax(formulario.getTelefone());
        referenciado.setEndereco(formulario.getEndereco());
        referenciado.setRazaoSocial(formulario.getNomeFantasia());
                
        session.setAttribute("referenciado", referenciado);
        session.setAttribute(STR_CODIGO_REFERENCIADO, formulario.getCodigoReferenciado());
        
        session.setAttribute("referenciadoFiltro", "true");
        
        gravaListaReferenciadoSaudeNaSessao(session);
        
        return forward;
    }

    @Log(levelOnException = LogLevel.FATAL)
    private void gravaListaReferenciadoSaudeNaSessao(HttpSession session) {
        TabelasCorporativasDelegate delegate = TabelasCorporativasDelegate.getInstance();
        ReferenciadoCondicoesGeraisVO vo = new  ReferenciadoCondicoesGeraisVO();
        StringBuilder stringListaReferenciadoSaude = new StringBuilder();
        
        vo.setNumeroReferenciado(Long.valueOf((session.getAttribute(STR_CODIGO_REFERENCIADO).toString())));
        ReferenciadoCondicoesGeraisVO referenciadoCondicoesGeraisVO = delegate.obterInformacoesReferenciadoCondicoesGerais(vo);
        
        stringListaReferenciadoSaude.append(referenciadoCondicoesGeraisVO.getStringCics0688().substring(0, 1032));
        stringListaReferenciadoSaude.append(String.format("%07d", referenciadoCondicoesGeraisVO.getCodigoCnes()));
        stringListaReferenciadoSaude.append(referenciadoCondicoesGeraisVO.getCampoComentarioArea());
        referenciadoCondicoesGeraisVO.setListaRefSaude(stringListaReferenciadoSaude.toString());
        
        session.setAttribute("listaRefSaude", referenciadoCondicoesGeraisVO.getListaRefSaude());
    }
    
    private void mensagemErro(HttpServletRequest request, String chave) {
        ActionMessages errors = new ActionMessages();
        MessageResources messageResources = getResources(request);
        errors.add(Globals.ERROR_KEY, new ActionMessage(Globals.ERROR_KEY, messageResources.getMessage(chave)));
        saveErrors(request, errors);
    }

    private boolean isSistemaEmManutencao(String cnpj) {
        ParametroVO parametroManutencao = ParametroDelegate.getInstance().consultarParametroPorNome("SENHA_WEB_EM_MANUTENCAO");
        if (parametroManutencao==null || parametroManutencao.getValor()==null || "N".equals(parametroManutencao.getValor())) {
            return false;
        }

        ParametroVO parametroUsuarios = ParametroDelegate.getInstance().consultarParametroPorNome("SENHA_WEB_MANUTENCAO_USUARIOS");
        if (parametroUsuarios==null || parametroUsuarios.getValor()==null) {
            return true;
        }

        List<String> cpfCnpjLiberados = converterStringParaListaString(parametroUsuarios.getValor());
        if (cpfCnpjLiberados.isEmpty()) {
            return true;
        }

        return !cpfCnpjLiberados.contains(cnpj);
    }

    private List<String> converterStringParaListaString(String entrada) {
        List<String> lista = new ArrayList<String>();
        if (entrada!=null && !"".equals(entrada.trim())) {
            for (String s : Arrays.asList(entrada.trim().split(","))) {
                lista.add(s.trim());
            }
        }
        return lista;
    }
}