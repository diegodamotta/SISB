package br.com.bradseg.sisb.solicitacaointernacaoexame.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import br.com.bradseg.bsad.exception.IntegrationException;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.analise.delegate.LoginDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.parametro.delegate.ParametroDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.GrupoVO;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.ParametroVO;
import br.com.cpmbraxis.framework.aop.annotation.Log;
import br.com.cpmbraxis.framework.type.LogLevel;

/**
 * Filtro do Login do SISB
 * @author Capgemini
 */
@SuppressWarnings("unchecked")
    
public class LoginFilter implements Filter {
  
    protected FilterConfig filterConfig;
    
    public static final String G_SISTEMAS_SISB = "G-SISTEMAS-SISB";    
    public static final String TELA_ERRO = "/SISB-SolicitacaoInternacaoExame/erroLdap.do";
    public static final String MSG_ERRO_LDAP = "mensagemErroLdap";    
    public static final String TELA_SELECAO_PERFIL = "/SISB-SolicitacaoInternacaoExame/selecaoPerfil.do";
    public static final String PERFIL_SELECIONADO = "perfilSelecionado";
    public static final String USUARIO_PERFIL = "usuarioPerfil";
    public static final String TELA_LOGIN_SISB = "/SISB-SolicitacaoInternacaoExame/";
    public static final String TELA_ATUALIZA_MATRICULA_OPERADOR = "/SISB-SolicitacaoInternacaoExame/telaAtualizaMatriculaOperador.do";
    public static final String MATRICULA_ATUALIZA = "matriculaAtualiza";
    public static final String EXIBIR_TROCAR_SENHA_AD = "exibirTrocarSenhaAD"; 
    public static final String VALIDAR_LOGIN_SISB = "/SISB-SolicitacaoInternacaoExame/validarLogin.do";
    public static final String LINK_TROCAR_SENHA_AD = "linkTrocarSenhaAD"; 
    public static final String LISTA_PERFIS_RECEBIDOS = "listaPerfisRecebidos";    
    public static final String DATA_EXPIRACAO_SENHA = "SENHA_LDAP_EXPIRAR";  
    public static final String DATA_EXPIRACAO_SENHA_ERRO = "SENHA_LDAP_EXPIRAR_ERRO"; 
    public static final String ERRO_IDM = "ERRO_IDM";
    public static final String CONSULTA_IDM = "consultaIDM";
    public static final String SISTEMA_EM_MANUTENCAO = "/SISB-SolicitacaoInternacaoExame/manutencao.do";
    
    private static final Logger LOGGER = Logger.getLogger(LoginFilter.class);
    
    private static List<GrupoVO> listaPerfilGeral = new ArrayList();
  
    public void init(FilterConfig filterConfig) throws ServletException {
       this.filterConfig = filterConfig;
    }
  
    public void destroy() {
       this.filterConfig = null;
       }
                                    
    /**
     * 
     * {@inheritDoc}
     */
    @Log(levelOnException = LogLevel.FATAL)
    public void doFilter(ServletRequest request, 
    ServletResponse response, FilterChain chain) 
        throws java.io.IOException, ServletException   {
    	
        HttpServletRequest req = (HttpServletRequest) request;  
        HttpServletResponse res = (HttpServletResponse) response;  
        boolean temAcesso = false;
        String msgRetornoLdap="";
      
        LoginService loginService = null;
        loginService = new LoginServiceImpl();
            
        String usuarioSisb="";
        int count = 0;
        List<GrupoVO> listaPerfilUsuario = new ArrayList<GrupoVO>();
        GrupoVO grupoSISB = new GrupoVO();
        LoginDelegate delegate = LoginDelegate.getInstance();
        String user = "";
        //String dataExpiracaoSenhaLdap = "";
        String pass = "";

        //Link bot�o de Trocar Senha
        req.getSession().setAttribute(LINK_TROCAR_SENHA_AD, loginService.botaoTrocarSenhaAD("52e"));
        
        //Ativar bot�o consulta IDM
        //req.getSession().setAttribute(CONSULTA_IDM, "ON");
        req.getSession().setAttribute(CONSULTA_IDM, "OFF");

        
        if(request.getParameter("login")!=null && !"".equals(request.getParameter("login")) ){
            user=request.getParameter("login");
        }
        
        if(request.getParameter("password")!=null && !"".equals(request.getParameter("password")) ){
            pass=request.getParameter("password");
        }

        //Para recuperar o Perfil Selecionado, 
        //caso o usu�rio possua mais de 1 perfil vinculado
        if(request.getParameter("resultado")!=null && !request.getParameter("resultado").equals("")){
            req.getSession().setAttribute(PERFIL_SELECIONADO, request.getParameter("resultado"));
            
            //16/01/2014 - Retirada da MSG da data expiracao de senha, pois j� foi exibida.
            req.getSession().removeAttribute(DATA_EXPIRACAO_SENHA);
            req.getSession().removeAttribute(DATA_EXPIRACAO_SENHA_ERRO);
            req.getSession().removeAttribute(ERRO_IDM);
        }

        //Requisi��o com usu�rio validado no AD   
        if(req.getSession().getAttribute("login") != null){ 
            chain.doFilter(request, response);
        }

        
        //fluxo valida��o acesso ou outro fluxo de redirect     
        else{
            
             if(user != null && !user.equals("") && pass != null && !pass.equals("") && req.getSession().getAttribute("AUTENTICADO_AD") == null) {
                    //Recupero o propertie com o De Para dos Perfis
                    try {
                        temAcesso=true;
 
                        if(listaPerfilGeral.isEmpty()){
                            listaPerfilGeral = loginService.pesquisarGruposAD();
                        }


                        if(req.getSession().getAttribute(LISTA_PERFIS_RECEBIDOS)!=null){
                            
                            listaPerfilUsuario.addAll((Collection<? extends GrupoVO>) req.getSession().getAttribute(LISTA_PERFIS_RECEBIDOS));
                            
                        }else{

                            grupoSISB = new GrupoVO();
                            grupoSISB.setNome("G-SISB-ACESSO");
                            listaPerfilUsuario.add(grupoSISB);
                        }

                        //Sem grupo do SISB vinculado no AD
                        if(listaPerfilUsuario.isEmpty()){
                            msgRetornoLdap = "Sem perfil vinculado no AD.";
                            req.getSession().setAttribute(MSG_ERRO_LDAP,msgRetornoLdap);
                            res.sendRedirect(TELA_ERRO);

                        }else{                 	

                            //Seto a lista de perfis do usuario na sessao
                            req.getSession().setAttribute(LISTA_PERFIS_RECEBIDOS,listaPerfilUsuario);
                            
                            //Buscando a quantidade de perfis vinculados ao usuario do SISB
                            count = delegate.buscarQuantidadePerfilUsuarioSisb(user); 
                            
                            //N�o possui perfil vinculado no SISB
                            if(count == 0){
                                temAcesso = false; 
                                msgRetornoLdap = "Sem perfil cadastrado na base do SISB.";
       
                            //Possui apenas um perfil
                            }else if(count == 1){ 
                                usuarioSisb = delegate.buscarLoginSisb(user);
                                
                                //Seto para ser possivel ir para tela de selecao de perfil,
                                //mesmo possuindo apenas 1 perfil
                                req.getSession().setAttribute(USUARIO_PERFIL,user);
                                
                                //Sem usu�rio cadastrado do SISB
                                if(usuarioSisb == null || usuarioSisb.equals("")){
                                    temAcesso = false; 
                                    msgRetornoLdap = "Sem usu�rio cadastrado na base do SISB.";
                                }  
                            
                            //Possui mais de um perfil    
                            }else if(count > 1){
                                req.getSession().setAttribute(USUARIO_PERFIL,user);
                            }

                            //P�s valida��o geral
                            if(temAcesso){
                                req.getSession().setAttribute("AUTENTICADO_AD","OK");

                                //Sistema est� em manuten��o e o usu�rio n�o tem acesso durante esse processo.
                                if (isSistemaEmManutencao(user)) {
                                    res.sendRedirect(SISTEMA_EM_MANUTENCAO);
                                }

                                //Usu�rio com mais de 1 perfil vinculado
                                else if(count > 1){
                                    res.sendRedirect(TELA_SELECAO_PERFIL);
                                }

                                //Usuario com apenas 1 perfil vinculado                                        
                                else if(count == 1){
                                    req.getSession().setAttribute("preLogin", usuarioSisb);
                                    res.sendRedirect(VALIDAR_LOGIN_SISB);
                                }
                            }

                            //P�gina com os erros de autentica��o no LDAP
                            else{
                                req.getSession().setAttribute(MSG_ERRO_LDAP,msgRetornoLdap);
                                res.sendRedirect(TELA_ERRO);
                            }
                        }                    
                    } catch (IntegrationException e) {
                        LOGGER.error(e.getMessage(), e);
                        throw new IOException();
                    }
            //outro fluxo de redirect       
            }else{
                chain.doFilter(request, response);
            }
        }
    }

    private boolean isSistemaEmManutencao(String matricula) throws IntegrationException {
        if (matricula == null) {
            throw new IntegrationException("A matricula est� em branco.");
        }
        
        matricula = matricula.trim().toUpperCase();

        //Se o sistema n�o estiver em manuten��o
        ParametroVO parametroManutencao = ParametroDelegate.getInstance().consultarParametroPorNome("SISB_EM_MANUTENCAO");
        if (parametroManutencao==null || parametroManutencao.getValor()==null || "N".equals(parametroManutencao.getValor())) {
            return false;
        }

        //Se n�o tiver lista de usu�rios est� em manuten��o para todo mundo.
        ParametroVO parametroUsuarios = ParametroDelegate.getInstance().consultarParametroPorNome("SISB_MANUTENCAO_USUARIOS");
        if (parametroUsuarios==null || parametroUsuarios.getValor()==null) {
            return true;
        }
        
        List<String> matriculasLiberadas = new ArrayList<String>();
        String valorParametroUsuarios = parametroUsuarios.getValor();
        if (valorParametroUsuarios!=null && !"".equals(valorParametroUsuarios.trim())) {
            valorParametroUsuarios = valorParametroUsuarios.trim();
            for (String matriculaUsuario : Arrays.asList(valorParametroUsuarios.split(","))) {
                matriculasLiberadas.add(matriculaUsuario.trim().toUpperCase());
            }
        }
        if (matriculasLiberadas.isEmpty()) {
            return true;
        }

        //Se ele n�o estiver na lista o sistema est� em manuten��o para ele.
        return !matriculasLiberadas.contains(matricula);
    }
}