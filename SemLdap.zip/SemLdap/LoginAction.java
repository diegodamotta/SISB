package br.com.bradseg.sisb.solicitacaointernacaoexame.controller.analise.action;

import javax.ejb.EJBException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bradseg.bsad.exception.IntegrationException;
import br.com.bradseg.sisb.solicitacaointernacaoexame.controller.form.LoginForm;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.analise.delegate.LoginDelegate;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.LoginVO;
import br.com.bradseg.sisb.solicitacaointernacaoexame.model.vo.UsuarioVO;
import br.com.bradseg.sisb.solicitacaointernacaoexame.util.ControleDeUsuarioSisbUtil;
import br.com.cpmbraxis.framework.aop.annotation.Log;
import br.com.cpmbraxis.framework.controller.struts.AbstractDispatchAction;
import br.com.cpmbraxis.framework.type.LogLevel;

/**
 * Classe responsavel pela a��es do login do SISB.
 * @author flavio.nascimento
 *
 */
public class LoginAction extends AbstractDispatchAction{    
    
    private static final String PRE_LOGIN = "preLogin";


	private static final Logger LOGGER = Logger.getLogger(LoginAction.class);
    
    
    public static final String FORWARD_SUCESSO_ATENDENTE = "sucessoAtendente";
    public static final String FORWARD_SUCESSO_MEDICO = "sucessoMedico";
    public static final String FORWARD_SUCESSO_CONSULTA = "sucessoConsulta";
    public static final String FORWARD_LOGIN = "login";
    public static final String MENSAGEM_ERRO = "Senha ou login inv�lidos!";
    public static final String MENSAGEM_ERRO_ALTERACAO = "Erro ao alterar a senha do usu�rio.";
    public static final String FORWARD_SUCESSO = "sucesso";
    public static final String NOME_USUARIO = "nomeUsuario";
    public static final String PERFIL = "perfil";
    public static final String PROJETO = "projeto";
    public static final String FORWARD_ERRO = "erro";
    public static final String FORWARD_ERRO_SESSAO = "sessao";
    public static final String PERFIL_SELECIONADO = "perfilSelecionado";
    public static final String MATRICULA_ATUALIZA = "matriculaAtualiza";
    public static final String TELA_ERRO = "erroLdap";
    public static final String MSG_ERRO_LDAP = "mensagemErroLdap"; 
    public static final String CDU = "cdU";
	public static final String FORWARD_SEGUNDA_OPINIAO = "sucessoSegundaOpiniao";
    
    
    /**
     * M�todo respons�vel pelo carregamento da p�gina de login
     * 
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     * @return
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward carregarLogin(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
      
        ActionForward forward = mapping.findForward(FORWARD_SUCESSO);
        
        invalidarSessao(request);
        
        if(request.getRequestURL().indexOf("wwws") != -1){
            forward = mapping.findForward(FORWARD_ERRO_SESSAO);
        }
     
        return forward;
    }

    /**
     * M�todo respons�vel por invalidar qualquer lixo da sess�o.
     * @param request
     */
    private void invalidarSessao(HttpServletRequest request) {
        HttpSession session = request.getSession();
          session.invalidate();
    }
    
    
     
    /**
     * Action responsavel pelo login no sistema.
     * 
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     * @return
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward login(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IntegrationException {
        ActionMessages errors = new ActionMessages();
        LoginDelegate delegate = LoginDelegate.getInstance();
        LoginForm loginForm = (LoginForm) form;
        LoginVO loginVO = new LoginVO();
        String login = null;
        UsuarioVO usuario = null;
        String nomeUsuario = null;
        String perfil = null;
        String codigoProjeto = null;  
        String user = "";
        String pass = "";		
        
        if( loginForm.getLogin()!=null && !"".equals(loginForm.getLogin()) ){
            user = loginForm.getLogin();
        }
        
        if( loginForm.getSenha()!=null && !"".equals(loginForm.getSenha()) ){
            pass = loginForm.getSenha(); 
        }

        //Caso tenha mais de 1 perfil, recupero o perfil selecionado
        if(request.getSession().getAttribute(PERFIL_SELECIONADO)!=null && !request.getSession().getAttribute(PERFIL_SELECIONADO).equals("")){
            user = (String) request.getSession().getAttribute(PERFIL_SELECIONADO);
        }

        //J� foi validado no AD
        else if(request.getSession().getAttribute(PRE_LOGIN) != null && !request.getSession().getAttribute(PRE_LOGIN).equals("")){
            user = (String) request.getSession().getAttribute(PRE_LOGIN);
        } 

        if(validarLoginSisbJaas(user,pass,request)){
           return mapping.findForward(FORWARD_LOGIN);
        } 

        loginVO.setLogin(user);
        loginVO.setSenha(pass);

        if (!delegate.validarProjeto(loginVO)){
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "Usu�rio n�o possui permiss�o para acessar o sistema.");
            errors.add(Globals.ERROR_KEY, message);
            saveErrors(request, errors);
            loginForm.setSenha("");

            return mapping.findForward(FORWARD_LOGIN);
        }

        request.getSession().setAttribute(FORWARD_LOGIN,loginVO.getLogin().toString());

        if (request.getSession().getAttribute(FORWARD_LOGIN) != null) {
            login = (String) request.getSession().getAttribute(FORWARD_LOGIN);
            try {
				usuario = delegate.obterUsuario(login);
				usuario.setPerfil(usuario.getPerfil().trim());
                nomeUsuario = usuario.getNomeUsuario();
                perfil = usuario.getPerfil().trim();
                codigoProjeto = usuario.getCodigoProjeto();
			} catch (EJBException e) {
			    LOGGER.error(e.getMessage(), e);
	            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "Erro ao obter os dados do usu�rio.");
	            errors.add(Globals.ERROR_KEY, message);
	            saveErrors(request, errors);
				return mapping.findForward(FORWARD_LOGIN);
			}
        }

        if ((nomeUsuario != null && !nomeUsuario.equals("")) || login != null) {
            request.getSession().setAttribute(FORWARD_LOGIN, login);
            request.getSession().setAttribute("codigoUsuario", login);
            request.getSession().setAttribute(CDU, login);
            request.getSession().setAttribute(NOME_USUARIO, nomeUsuario);
            request.getSession().setAttribute(PERFIL, perfil);
            request.getSession().setAttribute(PROJETO, codigoProjeto);
            request.getSession().setAttribute("horaLogin", loginForm.getDataHoraLogin());
        }

        if (    
        		"ATE.CAP".equals(request.getSession().getAttribute(PERFIL)) ||
            	"ATE.INTAO".equals(request.getSession().getAttribute(PERFIL)) ||
        		"ATE.SADT".equals(request.getSession().getAttribute(PERFIL)) ||
        		"ATE.INTSADT".equals(request.getSession().getAttribute(PERFIL)) ||
        		"ATE.DOM".equals(request.getSession().getAttribute(PERFIL))
        ) {
        	return mapping.findForward(FORWARD_SUCESSO_ATENDENTE);
        } else if (
        		"ADM.PROC".equals(request.getSession().getAttribute(PERFIL)) ||
        		"MED".equals(request.getSession().getAttribute(PERFIL)) ||
        		"COO".equals(request.getSession().getAttribute(PERFIL)) ||
        		"RME".equals(request.getSession().getAttribute(PERFIL)) ||
        		"CME".equals(request.getSession().getAttribute(PERFIL)) ||
        		"CAD".equals(request.getSession().getAttribute(PERFIL)) ||
        		"SUP".equals(request.getSession().getAttribute(PERFIL)) ||
        		"MEP".equals(request.getSession().getAttribute(PERFIL)) ||
        		"MED.DOM".equals(request.getSession().getAttribute(PERFIL))||
        		"RAD".equals(request.getSession().getAttribute(PERFIL))||
        		"ENF".equals(request.getSession().getAttribute(PERFIL)) ||
        		"MED.EXAM".equals(request.getSession().getAttribute(PERFIL))
        ) {
        	return mapping.findForward(FORWARD_SUCESSO_MEDICO);
        } else if (
        		"CON".equals(request.getSession().getAttribute(PERFIL)) ||
        		"ATDO.NMED".equals(request.getSession().getAttribute(PERFIL))
        ) {
        	return mapping.findForward(FORWARD_SUCESSO_CONSULTA);
        }else if ("ADM.SO".equals(request.getSession().getAttribute(PERFIL))){
            return mapping.findForward(FORWARD_SEGUNDA_OPINIAO);
        } else {
            loginForm.setSenha("");

			//Limpeza informa��es LDAP
            request.getSession().removeAttribute(FORWARD_LOGIN);
            request.getSession().removeAttribute("usuarioPerfil");
            request.getSession().removeAttribute("perfilSelecionado");
            request.getSession().removeAttribute("matriculaAtualiza");
            request.getSession().removeAttribute(PRE_LOGIN);
            request.getSession().removeAttribute("listaPerfisRecebidos");
            //Fim - Limpeza informa��es LDAP
			
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "Usu�rio n�o possui acesso ao SISB.");
            errors.add(Globals.ERROR_KEY, message);
            saveErrors(request, errors);
            return mapping.findForward(FORWARD_LOGIN);
        }
    }

    /**
     * M�todo para logout no sistema.
     * 
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     * @return
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward logout(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        
        HttpSession session = request.getSession();
        session.removeAttribute(FORWARD_LOGIN);
        session.removeAttribute("nome_operador");
        session.removeAttribute(PERFIL);
        //session.removeAttribute("operador");        
        //session.removeAttribute("projeto");
        
        session.invalidate();
       
        response.setHeader("Cache-Control","no-cache"); //HTTP 1.1   
        response.setHeader("Pragma","no-cache"); //HTTP 1.0   
        response.setDateHeader ("Expires", 0); //prevents caching   
        response.setHeader("Cache-Control","no-store"); //HTTP 1.1   
        
        return mapping.findForward(FORWARD_SUCESSO);
    }
    
    /**
     * M�todo respons�vel por encaminhar para a tela de troca de senha do usu�rio
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward trocaSenhaUsuario(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IntegrationException {

    	// M�todo utilizado para validar a sess�o do usu�rio.
    	ControleDeUsuarioSisbUtil.validaSessao(request);

    	return mapping.findForward(FORWARD_SUCESSO);
    	
    }

    /**
     * M�todo para trocar senha dos usu�rios do sistema.
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward trocarSenhaUsuario(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {        
        ActionMessages errors = new ActionMessages();
        LoginDelegate delegate = LoginDelegate.getInstance();
        LoginForm loginForm = (LoginForm) form;
        LoginVO loginVO = new LoginVO();
        
	    if(validarTrocaSenha(loginForm, request)){
	        return mapping.findForward(FORWARD_ERRO);
	    }
	    loginVO.setLogin(loginForm.getLogin());
	    loginVO.setSenha(loginForm.getSenhaAntiga());            
	    
	    if(! delegate.validarLogin(loginVO)){
	        ActionMessage message = new ActionMessage(Globals.ERROR_KEY, MENSAGEM_ERRO);
	        errors.add(Globals.ERROR_KEY, message);
	        saveErrors(request, errors);
	        return mapping.findForward(FORWARD_ERRO);
	    }
	
	    loginVO.setSenha(loginForm.getSenha());
	    delegate.trocarSenha(loginVO);     
	    incluirMensagem(request, true, "Sua senha foi alterada com sucesso.");
	
	    loginForm.setLogin("");
	    loginForm.setSenhaAntiga("");
	    loginForm.setSenha("");
	    loginForm.setConfirmaSenha("");

	    return mapping.findForward(FORWARD_SUCESSO);
    }      
        

    /**
     * M�todo validarLoginSisbJaas
     * @param login
     * @param senha
     * @param request
     * @return bool
     */
    private boolean validarLoginSisbJaas(String login, String senha, HttpServletRequest request) {
        ActionMessages errors = new ActionMessages();
        boolean retorno = false;
        
        if ((login==null || ("".equals(login) ))) {
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "� obrigat�rio informar um Login e uma Senha.");
            errors.add(Globals.ERROR_KEY, message);
            retorno = true;
        }
        if (retorno) {
            saveErrors(request, errors);
        }
        return retorno;
    }
    
    
    
    /**
     * M�todo utilizado para validar a troca de senha dos usu�rios do sisb.
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     */
    private boolean validarTrocaSenha(LoginForm loginForm, HttpServletRequest request) {
    	boolean retorno = false;
    	ActionMessages errors = new ActionMessages();
        LoginDelegate delegate = LoginDelegate.getInstance();
        LoginVO loginVO = new LoginVO();
        loginVO.setLogin(loginForm.getLogin());
        if ((loginForm.getLogin()==null || ("".equals(loginForm.getLogin()) || (loginForm.getSenha()==null ||  ("".equals(loginForm.getSenha())))))) {
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "� obrigat�rio informar um Login e uma Senha.");
            errors.add(Globals.ERROR_KEY, message);
            retorno = true;
        }
        if(loginForm.getConfirmaSenha()==null || ("".equals(loginForm.getConfirmaSenha()))){
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "� obrigat�rio confirmar a senha.");
            errors.add(Globals.ERROR_KEY, message);
            retorno = true;            
        }else if (!loginForm.getConfirmaSenha().equals(loginForm.getSenha())){           
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "As senhas informadas n�o s�o iguais.");
            errors.add(Globals.ERROR_KEY, message);
            retorno = true;              
        }
        if((!"".equals(loginForm.getLogin())) && (! delegate.verificarNomeUsuario(loginVO))){
            ActionMessage message = new ActionMessage(Globals.ERROR_KEY, "Usu�rio informado n�o existe.");
            errors.add(Globals.ERROR_KEY, message); 
            retorno = true;
        }           
        if (retorno) {
            saveErrors(request, errors);
        }
        return retorno;
    }
    
    /**
     * Carrega a p�gina de trocar senha 
     * @param mapping Par�metro do tipo ActionMapping contendo os dados do mapeamento do XML struts-config.xml
     * @param form Par�metro do tipo ActionForm contendo os dados do formul�rio web enviado
     * @param request Par�metro do tipo HttpServletRequest contendo os dados da requisi��o web
     * @param response Par�metro do tipo HttpServletResponse contendo os dados da p�gina a ser exibida
     */
    @Log(levelOnException = LogLevel.FATAL)
    public ActionForward trocaSenha(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
    	return mapping.findForward(FORWARD_SUCESSO);
    }
}